<?php
return [
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_NAME' => 'kelompk1_sandang_kota',
    'DB_USER' => 'kelompk1_user',
    'DB_PASSWORD' => 'ambafamili99',
];
